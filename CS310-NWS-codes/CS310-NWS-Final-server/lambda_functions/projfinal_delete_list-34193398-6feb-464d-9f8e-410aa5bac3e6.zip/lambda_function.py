import json
import os
import datatier
import auth
import api_utils

from configparser import ConfigParser

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: final_delete_list**")
    
    #
    # setup AWS based on config file
    #
    config_file = 'config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)
    
    #
    # configure for RDS access
    #
    rds_endpoint = configur.get('rds', 'endpoint')
    rds_portnum = int(configur.get('rds', 'port_number'))
    rds_username = configur.get('rds', 'user_name')
    rds_pwd = configur.get('rds', 'user_pwd')
    rds_dbname = configur.get('rds', 'db_name')

    #
    # get the access token from the request headers,
    # then get the user ID from the token
    #
    print("**Accessing request headers to get authenticated user info**")

    if "headers" not in event:
      return api_utils.error(400, "no headers in request")
    
    headers = event["headers"]

    token = auth.get_token_from_header(headers)

    if token is None:
      return api_utils.error(401, "no bearer token in headers")
    print("token:",token)
    try:
      user_id = auth.get_user_from_token(token, "mysecret")
    except Exception as e:
      return api_utils.error(401, "invalid access token")

    # CHANGE THIS
    userid = user_id
    
    print("userid:", userid)

    #
    # listid from event: could be a parameter
    # or could be part of URL path ("pathParameters")
    #
    body = json.loads(event["body"])
    listid = body["listid"]
    print("listid:", listid)

    #
    # open connection to the database
    #
    print("**Opening connection**")
    
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)
    
    #
    # retrieve all the music lists that user have admin
    #
    print("**Retrieving lists (admin)**")
    
    admin_sql = "SELECT listid FROM musiclists WHERE adminuserid = %s;"
    
    admin_rows = datatier.retrieve_all_rows(dbConn, admin_sql, [userid])
    admin_rows = [item for row in admin_rows for item in row]
    print("admin_rows:",admin_rows)

    if int(listid) not in admin_rows:
      return api_utils.error(403, "user does not have admin to the list")
    
    print("**Deleting list**")

    sql_delete_1 = "DELETE FROM listaccess WHERE listid = %s;"
    sql_delete_2 = "DELETE FROM musicinlist WHERE listid = %s;"
    sql_delete_3 = "DELETE FROM musiclists WHERE listid = %s;"

    datatier.perform_action(dbConn, sql_delete_1, [listid])
    datatier.perform_action(dbConn, sql_delete_2, [listid])
    datatier.perform_action(dbConn, sql_delete_3, [listid])
    
    #
    # retrieve all the music lists that user have admin
    #
    print("**Retrieving lists (admin)**")
    
    admin_sql = "SELECT (listid, listname) FROM musiclists WHERE adminuserid = %s;"
    
    admin_rows = datatier.retrieve_all_rows(dbConn, admin_sql, [userid])
    
    for row in admin_rows:
      print(row)

    #
    # respond in an HTTP-like way, i.e. with a status
    # code and body in JSON format
    #
    print("**DONE, returning rows**")
    
    return api_utils.success(200, {"admin list": admin_rows})
    
  except Exception as err:
    print("**ERROR**")
    print(str(err))

    return api_utils.error(500, str(err))
