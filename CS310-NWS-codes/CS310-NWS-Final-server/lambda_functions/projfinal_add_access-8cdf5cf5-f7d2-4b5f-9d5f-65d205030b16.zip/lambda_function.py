import json
import os
import datatier
import auth
import api_utils

from configparser import ConfigParser

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: final_music_lists**")
    
    #
    # setup AWS based on config file
    #
    config_file = 'config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)
    
    #
    # configure for RDS access
    #
    rds_endpoint = configur.get('rds', 'endpoint')
    rds_portnum = int(configur.get('rds', 'port_number'))
    rds_username = configur.get('rds', 'user_name')
    rds_pwd = configur.get('rds', 'user_pwd')
    rds_dbname = configur.get('rds', 'db_name')

    #
    # get the access token from the request headers,
    # then get the user ID from the token
    #
    print("**Accessing request headers to get authenticated user info**")

    if "headers" not in event:
      return api_utils.error(400, "no headers in request")
    
    headers = event["headers"]

    token = auth.get_token_from_header(headers)

    if token is None:
      return api_utils.error(401, "no bearer token in headers")
      
    try:
      user_id = auth.get_user_from_token(token, "mysecret")
    except Exception as e:
      return api_utils.error(401, "invalid access token")

    # CHANGE THIS
    userid = user_id
    
    print("userid:", userid)

    #
    # read the adduserid and listid from the event body
    #
    print("**Accessing request body**")

    if "body" not in event:
        return api_utils.error(400, "no body in request")
    
    body = json.loads(event["body"])

    if "addusername" not in body or "listid" not in body:
        return api_utils.error(400, "missing credentials in body")
    
    addusername = body["addusername"]
    listid = body["listid"]

    #
    # open connection to the database
    #
    print("**Opening connection**")
    
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)
    
    sql = "SELECT userid FROM users WHERE username = %s;"
    adduserid = datatier.retrieve_one_row(dbConn, sql, [addusername])
    
    if adduserid is ():
      return api_utils.error(410,"The user to be added does not exists")
    print("adduserid:",adduserid)
    adduserid = adduserid[0]
    
    #
    # retrieve all the music lists that user have admin
    #
    print("**Retrieving lists (admin)**")
    
    admin_sql = "SELECT listid FROM musiclists WHERE adminuserid = %s;"
    
    admin_rows = datatier.retrieve_all_rows(dbConn, admin_sql, [userid])

    admin_rows = [item for row in admin_rows for item in row]
    print("admin_rows:",admin_rows)

    if int(listid) not in admin_rows:
      return api_utils.error(403, "user does not have admin to the list")
    
    sql_existing_access = "SELECT * FROM listaccess WHERE listid = %s AND accessuserid = %s;"

    existing_access = datatier.retrieve_one_row(dbConn, sql_existing_access, [listid, adduserid])

    if existing_access is not ():
        return api_utils.error(409, "user already has access to the list")
    
    print("**Adding access**")

    sql_insert = "INSERT INTO listaccess (listid, accessuserid) VALUES (%s, %s);"

    datatier.perform_action(dbConn, sql_insert, [listid, adduserid])

    sql_access = "SELECT users.userid, users.username FROM users JOIN listaccess ON users.userid = listaccess.accessuserid WHERE listaccess.listid = %s;"

    access_rows = datatier.retrieve_all_rows(dbConn, sql_access, [listid])

    for row in access_rows:
      print(row)

    #
    # respond in an HTTP-like way, i.e. with a status
    # code and body in JSON format
    #
    print("**DONE, returning rows**")
    
    return api_utils.success(200, {
      'message': "access added",
    })
    
  except Exception as err:
    print("**ERROR**")
    print(str(err))

    return api_utils.error(500, str(err))
