import json
import os
import datatier
import auth
import api_utils

from configparser import ConfigParser

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: final_musics_in_list**")
    
    #
    # setup AWS based on config file
    #
    config_file = 'config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)
    
    #
    # configure for RDS access
    #
    rds_endpoint = configur.get('rds', 'endpoint')
    rds_portnum = int(configur.get('rds', 'port_number'))
    rds_username = configur.get('rds', 'user_name')
    rds_pwd = configur.get('rds', 'user_pwd')
    rds_dbname = configur.get('rds', 'db_name')

    #
    # listid from event: could be a parameter
    # or could be part of URL path ("pathParameters")
    #
    if "listid" in event:
      listid = event["listid"]
    elif "pathParameters" in event:
      if "listid" in event["pathParameters"]:
        listid = event["pathParameters"]["listid"]
      else:
        return api_utils.error(400, "no listid in pathParameters")
    else:
      return api_utils.error(400, "no listid in event")
        
    print("listid:", listid)

    #
    # get the access token from the request headers,
    # then get the user ID from the token
    #
    print("**Accessing request headers to get authenticated user info**")

    if "headers" not in event:
      return api_utils.error(400, "no headers in request")
    
    headers = event["headers"]

    token = auth.get_token_from_header(headers)

    if token is None:
      return api_utils.error(401, "no bearer token in headers")
      
    try:
      user_id = auth.get_user_from_token(token, "mysecret")
    except Exception as e:
      return api_utils.error(401, "invalid access token")

    # CHANGE THIS
    userid = user_id
    
    print("userid:", userid)

    #
    # open connection to the database
    #
    print("**Opening connection**")
    
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)
    
    print("**Checking listid status**")

    sql = "SELECT * FROM musiclists WHERE listid = %s;"
    
    row = datatier.retrieve_one_row(dbConn, sql, [listid])
    
    if row == ():  # no such list
      print("**No such list, returning...**")
      return api_utils.error(404, "no such job")
    
    print(row)

    #
    # retrieve all the music lists that user have admin
    #
    print("**Retrieving lists (admin)**")
    
    admin_sql = "SELECT listid FROM musiclists WHERE adminuserid = %s;"
    
    admin_rows = datatier.retrieve_all_rows(dbConn, admin_sql, [userid])
    
    for row in admin_rows:
      print(row)

    #
    # retrieve all the music lists that user have access
    #
    print("**Retrieving lists (access)**")
    
    access_sql = "SELECT musiclists.listid FROM musiclists JOIN listaccess ON musiclists.listid = listaccess.listid WHERE listaccess.accessuserid = %s;"
    
    access_rows = datatier.retrieve_all_rows(dbConn, access_sql, [userid])
    
    for row in access_rows:
      print(row)

    if listid not in access_rows and listid not in admin_rows:
      return api_utils.error(403, "list does not belong to user")
    
    #
    # retrieve all the music in the list
    #
    print("**Retrieving musics**")
    
    musics_sql = "SELECT musics.* FROM musics JOIN musicinlist ON musics.musicid = musicinlist.musicid WHERE musicinlist.listid = %s;"

    music_rows = datatier.retrieve_all_rows(dbConn, musics_sql, [listid])

    for row in music_rows:
      print(row)

    #
    # respond in an HTTP-like way, i.e. with a status
    # code and body in JSON format
    #
    print("**DONE, returning rows**")
    
    return api_utils.success(200, music_rows)
    
  except Exception as err:
    print("**ERROR**")
    print(str(err))

    return api_utils.error(500, str(err))
