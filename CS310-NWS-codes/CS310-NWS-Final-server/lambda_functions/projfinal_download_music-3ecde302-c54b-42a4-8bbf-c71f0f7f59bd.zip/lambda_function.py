import json
import boto3
import os
import base64
import datatier
import auth
import api_utils

from configparser import ConfigParser

def lambda_handler(event, context):
  try:
    print("**STARTING**")
    print("**lambda: final_musics**")

    #
    # setup AWS based on config file
    #
    config_file = 'config.ini'
    os.environ['AWS_SHARED_CREDENTIALS_FILE'] = config_file
    
    configur = ConfigParser()
    configur.read(config_file)

    #
    # configure for S3 access
    #
    s3_profile = 's3readwrite'
    boto3.setup_default_session(profile_name=s3_profile)
    
    bucketname = configur.get('s3', 'bucket_name')
    
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucketname)
    
    #
    # configure for RDS access
    #
    rds_endpoint = configur.get('rds', 'endpoint')
    rds_portnum = int(configur.get('rds', 'port_number'))
    rds_username = configur.get('rds', 'user_name')
    rds_pwd = configur.get('rds', 'user_pwd')
    rds_dbname = configur.get('rds', 'db_name')

    #
    # listid from event: could be a parameter
    # or could be part of URL path ("pathParameters")
    # #
    # if "listid" in event:
    #   listid = event["listid"]
    # elif "pathParameters" in event:
    #   if "listid" in event["pathParameters"]:
    #     listid = event["pathParameters"]["listid"]
    #   else:
    #     return api_utils.error(400, "no listid in pathParameters")
    # else:
    #   return api_utils.error(400, "no listid in event")
    if "body" not in event:
        return api_utils.error(400, "no body in request")
    
    body = json.loads(event["body"])
    listid = body["listid"]
    print("listid:", listid)
        
    # print("listid:", listid)
    
    #
    # get the access token from the request headers,
    # then get the user ID from the token
    #
    print("**Accessing request headers to get authenticated user info**")

    if "headers" not in event:
      return api_utils.error(400, "no headers in request")
    
    headers = event["headers"]

    token = auth.get_token_from_header(headers)

    if token is None:
      return api_utils.error(401, "no bearer token in headers")
      
    try:
      user_id = auth.get_user_from_token(token, "mysecret")
    except Exception as e:
      return api_utils.error(401, "invalid access token")

    # CHANGE THIS
    userid = user_id
    print("userid:", userid)

    #
    # read information from the event body
    #
    print("**Accessing request body**")


    if "musicid" not in body:
        return api_utils.error(400, "missing credentials in body")
    
    musicid = body["musicid"]
    print("musicid:", musicid)

    #
    # open connection to the database
    #
    print("**Opening connection**")
    
    dbConn = datatier.get_dbConn(rds_endpoint, rds_portnum, rds_username, rds_pwd, rds_dbname)

    print("**Checking listid status**")

    sql = "SELECT * FROM musiclists WHERE listid = %s;"
    
    row = datatier.retrieve_one_row(dbConn, sql, [listid])
    
    if row == ():  # no such list
      print("**No such list, returning...**")
      return api_utils.error(404, "no such list")

    #
    # retrieve all the music lists that user have admin
    #
    print("**Retrieving lists (admin)**")
    
    admin_sql = "SELECT listid FROM musiclists WHERE adminuserid = %s;"
    
    admin_rows = datatier.retrieve_all_rows(dbConn, admin_sql, [userid])
    
    for row in admin_rows:
      print(row)

    #
    # retrieve all the music lists that user have access
    #
    print("**Retrieving lists (access)**")
    
    access_sql = "SELECT musiclists.listid FROM musiclists JOIN listaccess ON musiclists.listid = listaccess.listid WHERE listaccess.accessuserid = %s;"
    
    access_rows = datatier.retrieve_all_rows(dbConn, access_sql, [userid])
    
    for row in access_rows:
      print(row)

    # if listid not in access_rows and listid not in admin_rows:
    #   return api_utils.error(403, "user does not have access to the list")
    
    sql_check_music = "SELECT musicid FROM musicinlist WHERE listid = %s;"
    
    check_music_rows = datatier.retrieve_all_rows(dbConn, sql_check_music, [listid])

    for row in check_music_rows:
      print(row)

    # if musicid not in check_music_rows:
    #   return api_utils.error(403, "music does not exist in the list")
    
    sql_music = "SELECT * FROM musics WHERE musicid = %s;"

    music_row = datatier.retrieve_one_row(dbConn, sql_music, [musicid])

    print(music_row)

    if music_row is ():
      return api_utils.error(403, "music does not exist")
    
    musicfile = music_row[1]
    musicname = music_row[2]
    artist = music_row[3]
    albumid = music_row[4]

    sql_album = "SELECT * FROM albums WHERE albumid = %s;"

    album_row = datatier.retrieve_one_row(dbConn, sql_album, [albumid])

    print(album_row)

    if album_row is ():
      return api_utils.error(403, "album does not exist")
    
    albumname = album_row[1]
    albumart = album_row[2]

    #
    # download album art
    #
    album_local_filename = "/tmp/album.jpg"
    
    print("**Downloading album art from S3**")
    
    bucket.download_file(albumart, album_local_filename)
    
    #
    # open the file and read as raw bytes:
    #
    album_infile = open(album_local_filename, "rb")
    album_bytes = album_infile.read()
    album_infile.close()
    
    #
    # now encode the data as base64. Note b64encode returns
    # a bytes object, not a string. So then we have to convert
    # (decode) the bytes -> string, and then we can serialize
    # the string as JSON for download
    #
    album_data = base64.b64encode(album_bytes)
    album_datastr = album_data.decode()

    #
    # download music
    #
    music_local_filename = "/tmp/music.mp3"
    
    print("**Downloading music from S3**")
    
    bucket.download_file(musicfile, music_local_filename)
    
    #
    # open the file and read as raw bytes:
    #
    music_infile = open(music_local_filename, "rb")
    music_bytes = music_infile.read()
    music_infile.close()
    
    #
    # now encode the data as base64. Note b64encode returns
    # a bytes object, not a string. So then we have to convert
    # (decode) the bytes -> string, and then we can serialize
    # the string as JSON for download
    #
    music_data = base64.b64encode(music_bytes)
    music_datastr = music_data.decode()

    print("**DONE, returning results**")
    
    #
    # respond in an HTTP-like way, i.e. with a status
    # code and body in JSON format
    #
    body = {
      'album data': album_datastr,
      'music data': music_datastr,
      'music name': musicname,
      'artist': artist,
      'album name': albumname
    }
    return api_utils.success(200, body)
    
  except Exception as err:
    print("**ERROR**")
    print(str(err))

    return api_utils.error(500, str(err))
